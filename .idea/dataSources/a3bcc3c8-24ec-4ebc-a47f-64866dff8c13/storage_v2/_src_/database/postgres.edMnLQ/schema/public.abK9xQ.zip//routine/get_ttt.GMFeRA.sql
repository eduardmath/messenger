create function get_ttt(in_person_id integer)
    returns TABLE(first_name character varying, last_name character varying, date_of_birth date)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT t.first_name, t.last_name, t.date_of_birth
        FROM ttt t
        where t.id = in_person_id;
END
$$;

alter function get_ttt(integer) owner to postgres;

